/*
 * Copyright (C) 2018, Liberty Mutual Group
 
 */

package exceptions;

/**
 * @author n0219941
 *
 */


import java.io.*;

public class NumberFormat {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) throws NumberFormatException, IOException{ 
		// TODO Auto-generated method stub
		
		int toNum=0;
		int tocost =0;
		int vle =0;
		BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the total number of items");
		toNum = Integer.parseInt(buf.readLine());
		
		
		for (int i=0; i<toNum;i++){
			System.out.println("Enter the shipping price of the item "+(i+1)+" :");
			try{
			vle =Integer.parseInt(buf.readLine());
			}catch (NumberFormatException  e){
			System.out.println("Exception : java.lang.NumberFormatException");
				 System.out.println ("Re-enter the item price :");
                  vle =Integer.parseInt(buf.readLine());
							 
			}
			
			tocost= tocost+vle;
		}
		
		System.out.println("Total cost of the container is "+tocost);


	}

}
