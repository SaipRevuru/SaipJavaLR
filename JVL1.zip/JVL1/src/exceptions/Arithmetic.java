/*
 * Copyright (C) 2018, Liberty Mutual Group

 */

package exceptions;

/**
 * @author n0219941
 *
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Arithmetic {
	
    public static void main(String[] args) throws IOException{
		int pri = 0;
		int  noc = 0;
		// TODO Auto-generated method stub
		BufferedReader exp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the container price :");
				
		pri = Integer.parseInt(exp.readLine());
		System.out.println("Enter the number of items in the container :");
		 
		noc = Integer.parseInt(exp.readLine());
			
			  try {
				  
			System.out.println("The average price of the item is Rs."+(pri/noc));
			  }catch  (ArithmeticException e){
				  System.out.println("Exception : java.lang.ArithmeticException");
				  
				  System.out.println("Enter the container price :");
					
					
					pri = Integer.parseInt(exp.readLine());
					System.out.println("Enter the number of items in the container :");
					 
					noc = Integer.parseInt(exp.readLine());
					System.out.println("The average price of the item is Rs."+(pri/noc));
			  }
	}

   
}
