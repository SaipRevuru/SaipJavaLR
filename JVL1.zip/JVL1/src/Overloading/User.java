/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Jun 7, 2018
 */

package Overloading;

/**
 * @author n0219941
 *
 */
public class User {
	
	 private String userName;
	    private String firstName;
	    private String lastName;
	    private String contact;

	    public User(String userName, String firstName, String lastName, String contact) {
	        this.userName = userName;
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.contact = contact;
	    }

	    User() {}

	    public String getUserName() {
	        return userName;
	    }

	    public void setUserName(String userName) {
	        this.userName = userName;
	    }

	    public String getFirstName() {
	        return firstName;
	    }

	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }

	    public String getLastName() {
	        return lastName;
	    }

	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }

	    public String getContact() {
	        return contact;
	    }

	    public void setContact(String contact) {
	        this.contact = contact;
	    }
	    //fill your code
	   public User findUser(User userArray[],String userNamess){
	      // System.out.println("Inside method");
		   for (int i = 0; i<userArray.length;i++){
			  if( userArray[i].userName.equalsIgnoreCase(userNamess)){
				  //System.out.println("User details :");
				  return userArray[i];
			  }
		   }
		   
		return null;
	    	
	    }
	    
	   public User findUser(User userArray[],String firstName,String lastName){
		   
		   for (int i = 0; i<userArray.length;i++){
			  if( (userArray[i].firstName.equalsIgnoreCase(firstName))&&(userArray[i].lastName.equalsIgnoreCase(lastName))){
				  //System.out.println("User details :");
				  return userArray[i];
			  }
		   }
		  
		   
		return null;
		     }
	   

}
