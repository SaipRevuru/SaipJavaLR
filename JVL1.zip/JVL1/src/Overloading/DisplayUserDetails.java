/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Jun 7, 2018
 */

package Overloading;

/**
 * @author n0219941
 *
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DisplayUserDetails {

	/**
	 * @param args
	 * @throws IOException 
	 */
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the total number of users");
    	InputStreamReader sx = new InputStreamReader(System.in);
    	BufferedReader rd = new BufferedReader(sx);
    	int num = Integer.parseInt(rd.readLine());
    	User [] uc= new User[num];
    	for (int i = 0; i<num;i++){
    		uc[i]= new User(null, null, null, null);
    	}
    	System.out.println("Enter user details");
    	
    	String userName, firstName,lastName,contact, username,fn,ln;
    	String [] splitstring = new String[4];
 
    	for (int i = 0; i<num;i++){

    	    		
			//System.out.println(rd.readLine());
			splitstring = rd.readLine().split(",");
			 		
			userName = splitstring[0];
			//System.out.println("userName  " +userName);
			firstName = splitstring[1];
			//System.out.println("firstName "+firstName);
			lastName = splitstring[2];
			//System.out.println("lastName"+ lastName);
			contact = splitstring[3];
			//System.out.println("contact  "+contact);
			
			 uc[i]=  new User(userName,firstName,lastName,contact);
			 
		    		    	}
    	System.out.println("1)Search user by user name\n2)Search user by first name and last name\nEnter your option");
    	String option =  rd.readLine();
    	User  ucs= new User();
    	User ret = new User();
    	switch (option)
    	{
    		case "1":
    			System.out.println("Enter the user name to search");
    			username = rd.readLine();
    			//System.out.println("ENtered name is "+username);
    			ret = ucs.findUser(uc, username);
    			
    			if (ret == null){
    				System.out.println("User not found");
    				
    			}else{
    				System.out.println("User details :");
    				System.out.println("Username :"+ret.getUserName());
    				System.out.println("FirstName :"+ret.getFirstName());
    				System.out.println("LastName :"+ret.getLastName());
    				System.out.println("Contact :"+ret.getContact());
    				
    			}
    		
    			break ;
    		case "2":
    		    System.out.println("Enter the first name to search");
    			System.out.println("Enter the last name to search");
    			fn = rd.readLine();
    			ln = rd.readLine();
    			ret = ucs.findUser(uc, fn,ln);
    			if (ret == null){
    				System.out.println("User not found");
    				
    			}else{
    				System.out.println("User details :");
    				System.out.println("Username :"+ret.getUserName());
    				System.out.println("FirstName :"+ret.getFirstName());
    				System.out.println("LastName :"+ret.getLastName());
    				System.out.println("Contact :"+ret.getContact());
    				
    			}
    			break;
    			
    	}
    	
    }

	}


