/*
 * Copyright (C) 2018, Liberty Mutual Group
 */

/**
 * @author n0219941
 *
 */
public class Loops2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	      int x = 10;

	      while( x < 20 ) {
	         System.out.print("value of x : " + x );
	         x++;
	         System.out.print("\n");
	      }
	      
	      int y = 10;

	      do {
	         System.out.print("value of y : " + y );
	         y++;
	         System.out.print("\n");
	      }while( y < 20 );

	}

}
