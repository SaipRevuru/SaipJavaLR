/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Jun 7, 2018
 */

package Inheritance;

/**
 * @author n0219941
 *
 */

import java.text.DecimalFormat;

public class AgentShipment extends Shipment {
	
    public AgentShipment(String name, String source, String destination,double price, double referalFee) {
    	super(name, source, destination, price);
        this.referalFee = referalFee;
		// TODO Auto-generated constructor stub
	}

	private double referalFee;

   
    
    public double getReferalFee() {
        return referalFee;
    }

    public void setReferalFee(double referalFee) {
        this.referalFee = referalFee;
    }
    
    @Override
    double calculateShipmentAmount()
    {
    	Double Totle;
    	Totle = this.getPrice()+this.referalFee;
    	
		return Totle;
		
		//return Double.NaN;
        //fill code here.
        
    }

}
