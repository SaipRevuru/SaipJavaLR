/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Jun 7, 2018
 */

package Inheritance;

/**
 * @author n0219941
 *
 */

import java.io.*;
import java.text.DecimalFormat;

public class Mainexe {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
	    String name,source,destination;
        double price, total;
        int choice;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the shipment name :");
        name = br.readLine();
        System.out.println("Enter the source :");
        source = br.readLine();
        System.out.println("Enter the destination :");
        destination = br.readLine();
        System.out.println("Enter the price :");
        price =Double.parseDouble(br.readLine());
        System.out.println("1. Agent\n2. Company\nEnter your choice :");
        choice = Integer.parseInt(br.readLine());
        Shipment shipment;
        //shipment = new Shipment(name, source, destination, price );
        if(choice == 1)
        {
            double referalFee;
            System.out.println("Enter the referal fee :");
            referalFee = Double.parseDouble(br.readLine());
            AgentShipment as =  new AgentShipment(name, source, destination, price, referalFee);
            
            as.setReferalFee(referalFee);
           System.out.println("Agent details :");
           
           total=  as.calculateShipmentAmount();
            System.out.format("%-15s %-15s %-15s %s\n","Name","Source","Destination","Total Amount");
    	     // System.out.format("%-15s %-15s %-15s %s\n",as.name,as.source,as.destination,as.calculateShipmentAmount());
    	     System.out.format("%-15s %-15s %-14s %.2f\n",as.name,as.source,as.destination,as.calculateShipmentAmount());

            
        }
        else if(choice == 2)
        {
            double luxuryTax,corporateTax;
            System.out.println("Enter the luxury tax and corporate tax:");
            luxuryTax = Double.parseDouble(br.readLine());
            corporateTax = Double.parseDouble(br.readLine());
            CompanyShipment cs = new CompanyShipment(name, source, destination, price, luxuryTax,corporateTax);
            
            cs.setLuxuryTax(luxuryTax);
            cs.setCorporateTax(corporateTax);
            System.out.println("Company details :");
            
            total=  cs.calculateShipmentAmount();
            System.out.format("%-15s %-15s %-15s %s\n","Name","Source","Destination","Total Amount");
            System.out.format("%-15s %-15s %-14s %.2f\n",cs.name,cs.source,cs.destination,cs.calculateShipmentAmount());

        
    }
		// TODO Auto-generated method stub

	}

}
