import java.util.Scanner;

/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Jun 6, 2018
 */

/**
 * @author n0219941
 *
 */
public class Array {

	/**
	 * @param args
	 */
	

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] thisIsAStringArray = {"Apple", "Banana", "Orange"};
		
		Scanner srchstrng = new Scanner(System.in);
		
		System.out.println("Enter the Fruit Name :");
		String stringToSearch = srchstrng.nextLine();
		//String stringToSearch = "Banana";
		boolean found = false;
		for (String element:thisIsAStringArray) {
		    if ( element.equals( stringToSearch )) {
		        found = true;
				break;
		    }
		}
		if (found) {
		    System.out.println( "The array contains the string: " + stringToSearch );
		} else {
		    System.out.println( "The array does not contains the string: " + stringToSearch );
		}
		
		///////////////////////////
		
		String[] SecondAStringArray = {"Java", "Dotnet", "Oracle"};
	    System.out.println( "The array contains the string Java: " + contains(SecondAStringArray, "Java") );
	    System.out.println( "The array contains the string Oracle: " + contains(SecondAStringArray, "Oracle") );
		

	}
	public static boolean contains(String[] stringArray, String stringToSearch)
	{
	    boolean result = false;
	    for (String element:stringArray) {
	        if ( element.equals( stringToSearch )) {
	            result = true;
	            break;
	        }
	    }
	    return result;
	}

}
