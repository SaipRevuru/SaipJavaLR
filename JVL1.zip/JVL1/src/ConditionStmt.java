/*
 * Copyright (C) 2018, Liberty Mutual Group

 */

/**
 * @author n0219941
 *
 */
/*
 * 
 * Rating the Bus Travel company 
 *
Grade Cities	Trips per month
A	Above 50	Above 1500
B	Above 25	Above 1200
C	Above 10	Above 1000
D	Above 5	    Above700
E	<=5 and >=0 <=700 and >=0
Invalid < 0	       < 0
 Input

*/
 

import java.util.Scanner;

public class ConditionStmt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Scanner travel = new Scanner(System.in);
		
		System.out.println("Enter the total number of citires the Services to :");
		int Coun = travel.nextInt();
		
		System.out.println("Enter the total number of Trips per month :");
		int num = travel.nextInt();
		
		if (Coun>50 && num > 1500){
			System.out.println("The company grade is : A");
		}else if (Coun>25 && num > 1200){
			System.out.println("The company grade is : B");
		} else if (Coun>10 && num > 1000){
			System.out.println("The company grade is : C");
		} else if (Coun>5 && num > 700){
			System.out.println("The company grade is : D");
		} else if (Coun <=5 && Coun >=0 && num>=0 && num <=700){
			System.out.println("The company grade is : E");
			} else  {
				System.out.println("Invalid Input");
			} 
			
	    travel.close();


	}

}
