/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Jun 8, 2018
 */

package abstractclass;

/**
 * @author n0219941
 *
 */
public class abstractMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  Salary s = new Salary("employee1", "employee2, ind", 3, 3600.00);
	      Employee e = new Salary("employee2", "dover, nh", 2, 2400.00);
	      System.out.println("Call mailCheck using Salary reference --");
	      s.mailCheck();
	      System.out.println("\n Call mailCheck using Employee reference--");
	      e.mailCheck();

	}

}
