/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Jun 8, 2018
 */

package Collections;

/**
 * @author n0219941
 *
 */

import java.util.*;

public class TreeMapTest {
	
	 public static void main(String args[]) {
	      // Create a hash map
	      TreeMap tm = new TreeMap();
	      
	      // Put elements to the map
	      tm.put("Student1", new Integer(90));
	      tm.put("Student2", new Integer(85));
	      tm.put("Student3", new Integer(76));
	      tm.put("Student4", new Integer(60));
	      tm.put("Student5", new Integer(52));
	      
	      // Get a set of the entries
	      Set set = tm.entrySet();
	      
	      // Get an iterator
	      Iterator i = set.iterator();
	      
	      // Display elements
	      while(i.hasNext()) {
	         Map.Entry me = (Map.Entry)i.next();
	         System.out.print(me.getKey() + ": ");
	         System.out.println(me.getValue());
	      }
	      System.out.println();
	      
	      
	      Integer totalmarks = ((Integer)tm.get("Student5")).intValue();
	      tm.put("Student5", new Integer(totalmarks + 20));
	      System.out.println("Student5 total marks: " + tm.get("Student5"));
	   }

}
