/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
  */

/**
 * @author n0219941
 *
 */

// Find the shopping receipt number is Prime to identify the eligibility for special gift coupon

import java.util.Scanner;

public class ConditionsAndLoops {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean isPrime=true;
		Scanner rctcde = new Scanner(System.in);
		
		System.out.println("Enter the Shoppping Receipt code :");
		int num = rctcde.nextInt();
		
		 for(int i=0; i < num; i++){
             
             //check to see if the number is prime
             for(int j=2; j < i ; j++){
                    
                     if(i % j == 0){
                             isPrime = false;
                             break;
                     }
             }
             
                     
     }
		// print the number
         if(isPrime){
        	 System.out.print("Sorry ! Try Again for Coupon"); 
         } else {
        	 System.out.print(" Hurray ! you got the Special Coupon"); 
         }
						
		//---------------
         rctcde.close();



	}

}
