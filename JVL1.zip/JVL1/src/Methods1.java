import java.util.Scanner;

/*
 * Copyright (C) 2018, Liberty Mutual Group

 */

/**
 * @author n0219941
 *
 */
public class Methods1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
        Scanner swap = new Scanner(System.in);
		
		System.out.println("Enter the value of a:");
		int a = swap.nextInt();
		
		System.out.println("Enter thevalue of b :");
		int b = swap.nextInt();
		
		System.out.println("Before swapping, a = " + a + " and b = " + b);

	      // Invoke the swap method
	      swapFunction(a, b);
	      System.out.println("\n**Now, Before and After swapping values will be same here**:");
	      System.out.println("After swapping, a = " + a + " and b is " + b);
	   }

	   public static void swapFunction(int a, int b) {
	      System.out.println("Before swapping(Inside), a = " + a + " b = " + b);
	      
	      // Swap n1 with n2
	      int c = a;
	      a = b;
	      b = c;
	      System.out.println("After swapping(Inside), a = " + a + " b = " + b);
	      
	     

	}

}
